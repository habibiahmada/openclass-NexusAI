# Data Processing Module
# Handles PDF extraction, text chunking, and metadata management